USE `banco_c#`;

-- Rode este arquivo somente se você quiser manter o banco antigo sem recriar as tabelas.

ALTER TABLE `pagamento`
  ADD COLUMN IF NOT EXISTS `beneficiario` VARCHAR(100) NOT NULL DEFAULT 'Não informado' AFTER `valor`;

-- Garante que cada cliente tenha um registro de saldo.
INSERT INTO `saldo` (`id_cliente`, `saldo_atual`)
SELECT c.id_cliente, 0.00
FROM `cliente` c
LEFT JOIN `saldo` s ON s.id_cliente = c.id_cliente
WHERE s.id_cliente IS NULL;

-- Se não houver duplicidade de saldo por cliente, esta chave pode ser criada.
ALTER TABLE `saldo`
  ADD UNIQUE KEY `uk_saldo_cliente` (`id_cliente`);
