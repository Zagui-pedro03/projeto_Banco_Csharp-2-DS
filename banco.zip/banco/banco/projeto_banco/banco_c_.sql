CREATE DATABASE IF NOT EXISTS `banco_c#`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE `banco_c#`;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `pagamento`;
DROP TABLE IF EXISTS `deposito`;
DROP TABLE IF EXISTS `emprestimo`;
DROP TABLE IF EXISTS `saldo`;
DROP TABLE IF EXISTS `cliente`;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `cliente` (
  `id_cliente` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `cpf` VARCHAR(14) NOT NULL,
  `telefone` VARCHAR(20) DEFAULT NULL,
  `email` VARCHAR(100) NOT NULL,
  `RG` VARCHAR(20) NOT NULL,
  `senha` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `uk_cliente_cpf` (`cpf`),
  UNIQUE KEY `uk_cliente_rg` (`RG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `saldo` (
  `id_saldo` INT NOT NULL AUTO_INCREMENT,
  `id_cliente` INT NOT NULL,
  `saldo_atual` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id_saldo`),
  UNIQUE KEY `uk_saldo_cliente` (`id_cliente`),
  CONSTRAINT `fk_saldo_cliente`
    FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `deposito` (
  `id_deposito` INT NOT NULL AUTO_INCREMENT,
  `id_cliente` INT NOT NULL,
  `valor` DECIMAL(10,2) NOT NULL,
  `data_deposito` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_deposito`),
  KEY `idx_deposito_cliente` (`id_cliente`),
  CONSTRAINT `fk_deposito_cliente`
    FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `pagamento` (
  `id_pagamento` INT NOT NULL AUTO_INCREMENT,
  `id_cliente` INT NOT NULL,
  `valor` DECIMAL(10,2) NOT NULL,
  `beneficiario` VARCHAR(100) NOT NULL,
  `data_pagamento` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pagamento`),
  KEY `idx_pagamento_cliente` (`id_cliente`),
  CONSTRAINT `fk_pagamento_cliente`
    FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `emprestimo` (
  `id_emprestimo` INT NOT NULL AUTO_INCREMENT,
  `id_cliente` INT NOT NULL,
  `valor` DECIMAL(10,2) NOT NULL,
  `quantidade_parcelas` INT NOT NULL,
  `valor_parcela` DECIMAL(10,2) NOT NULL,
  `data_emprestimo` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_emprestimo`),
  KEY `idx_emprestimo_cliente` (`id_cliente`),
  CONSTRAINT `fk_emprestimo_cliente`
    FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Registro de exemplo (pode apagar se quiser começar vazio)
INSERT INTO `cliente` (`nome`, `cpf`, `telefone`, `email`, `RG`, `senha`)
VALUES ('lucas', '4242424242', '69696969', 'lucas@gmail.com', '67676767', 'lucaxx');

INSERT INTO `saldo` (`id_cliente`, `saldo_atual`)
VALUES (LAST_INSERT_ID(), 0.00);
