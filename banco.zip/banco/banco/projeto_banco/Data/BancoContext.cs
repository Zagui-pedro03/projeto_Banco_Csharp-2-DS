using MySql.Data.MySqlClient;

namespace projeto_banco.Data
{
    public class BancoContext
    {
        private readonly string _connectionString;

        public BancoContext(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("A conexão DefaultConnection não foi configurada.");
        }

        public MySqlConnection CriarConexao()
        {
            return new MySqlConnection(_connectionString);
        }
    }
}
