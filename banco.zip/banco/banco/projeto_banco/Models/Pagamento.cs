using System.ComponentModel.DataAnnotations;

namespace projeto_banco.Models
{
    public class Pagamento
    {
        public int Id { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Selecione um cliente.")]
        public int IdCliente { get; set; }

        [Range(0.01, 999999999, ErrorMessage = "O valor do pagamento deve ser maior que zero.")]
        public decimal ValorPago { get; set; }

        public DateTime DataRealizacao { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Informe o beneficiário.")]
        public string Beneficiario { get; set; } = string.Empty;

        public Cliente? Cliente { get; set; }
    }
}
