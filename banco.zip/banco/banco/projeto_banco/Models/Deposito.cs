using System.ComponentModel.DataAnnotations;

namespace projeto_banco.Models
{
    public class Deposito
    {
        public int Id { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Selecione um cliente.")]
        public int IdCliente { get; set; }

        [Range(0.01, 999999999, ErrorMessage = "O valor do depósito deve ser maior que zero.")]
        public decimal ValorDeposito { get; set; }

        public DateTime DataDeposito { get; set; } = DateTime.Now;
        public Cliente? Cliente { get; set; }
    }
}
