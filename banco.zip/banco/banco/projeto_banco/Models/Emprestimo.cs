using System.ComponentModel.DataAnnotations;

namespace projeto_banco.Models
{
    public class Emprestimo
    {
        public int Id { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Selecione um cliente.")]
        public int IdCliente { get; set; }

        [Range(0.01, 999999999, ErrorMessage = "O valor do empréstimo deve ser maior que zero.")]
        public decimal ValorEmprestimo { get; set; }

        [Range(1, 120, ErrorMessage = "A quantidade de parcelas deve ser entre 1 e 120.")]
        public int QuantidadeParcelas { get; set; }

        public decimal ValorParcela { get; set; }
        public DateTime DataEmprestimo { get; set; } = DateTime.Now;
        public Cliente? Cliente { get; set; }
    }
}
