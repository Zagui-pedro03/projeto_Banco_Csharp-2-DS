namespace projeto_banco.Models.ViewModels
{
    public class ClienteCompletoViewModel
    {
        public Cliente Cliente { get; set; } = new();
        public Saldo Saldo { get; set; } = new();
        public List<Emprestimo> Emprestimos { get; set; } = new();
        public List<Pagamento> Pagamentos { get; set; } = new();
        public List<Deposito> Depositos { get; set; } = new();
    }
}
