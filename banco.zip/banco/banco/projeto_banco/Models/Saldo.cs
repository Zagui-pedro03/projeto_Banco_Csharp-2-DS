namespace projeto_banco.Models
{
    public class Saldo
    {
        public int Id { get; set; }
        public int IdCliente { get; set; }
        public decimal SaldoAtual { get; set; }
        public Cliente? Cliente { get; set; }
    }
}
