using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using projeto_banco.Data;
using projeto_banco.Models;
using projeto_banco.Models.ViewModels;

namespace projeto_banco.Controllers
{
    public class ClienteController : Controller
    {
        private readonly BancoContext _banco;

        public ClienteController(BancoContext banco)
        {
            _banco = banco;
        }

        public IActionResult Index()
        {
            var clientes = new List<Cliente>();

            using var conexao = _banco.CriarConexao();
            conexao.Open();

            const string sql = @"
                SELECT id_cliente, nome, cpf, telefone, email, RG, senha
                FROM cliente
                ORDER BY nome;";

            using var comando = new MySqlCommand(sql, conexao);
            using var leitor = comando.ExecuteReader();

            while (leitor.Read())
            {
                clientes.Add(LerCliente(leitor));
            }

            return View(clientes);
        }

        public IActionResult Detalhes(int id)
        {
            using var conexao = _banco.CriarConexao();
            conexao.Open();

            var cliente = BuscarCliente(conexao, id);
            if (cliente == null)
                return NotFound();

            var vm = new ClienteCompletoViewModel
            {
                Cliente = cliente,
                Saldo = BuscarSaldo(conexao, id),
                Depositos = BuscarDepositos(conexao, id),
                Pagamentos = BuscarPagamentos(conexao, id),
                Emprestimos = BuscarEmprestimos(conexao, id)
            };

            return View(vm);
        }

        [HttpGet]
        public IActionResult Cadastrar()
        {
            return View(new Cliente());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cadastrar(Cliente cliente)
        {
            if (!ModelState.IsValid)
                return View(cliente);

            using var conexao = _banco.CriarConexao();
            conexao.Open();
            using var transacao = conexao.BeginTransaction();

            try
            {
                const string sqlCliente = @"
                    INSERT INTO cliente (nome, cpf, telefone, email, RG, senha)
                    VALUES (@nome, @cpf, @telefone, @email, @rg, @senha);";

                using var comando = new MySqlCommand(sqlCliente, conexao, transacao);
                comando.Parameters.AddWithValue("@nome", cliente.Nome);
                comando.Parameters.AddWithValue("@cpf", cliente.CPF);
                comando.Parameters.AddWithValue("@telefone", cliente.Tel);
                comando.Parameters.AddWithValue("@email", cliente.Email);
                comando.Parameters.AddWithValue("@rg", cliente.RG);
                comando.Parameters.AddWithValue("@senha", cliente.Senha);
                comando.ExecuteNonQuery();

                var idCliente = Convert.ToInt32(comando.LastInsertedId);

                const string sqlSaldo = @"
                    INSERT INTO saldo (id_cliente, saldo_atual)
                    VALUES (@idCliente, 0.00);";

                using var comandoSaldo = new MySqlCommand(sqlSaldo, conexao, transacao);
                comandoSaldo.Parameters.AddWithValue("@idCliente", idCliente);
                comandoSaldo.ExecuteNonQuery();

                transacao.Commit();
                TempData["Sucesso"] = "Cliente cadastrado com sucesso.";
                return RedirectToAction(nameof(Index));
            }
            catch (MySqlException ex)
            {
                transacao.Rollback();
                ModelState.AddModelError(string.Empty,
                    ex.Number == 1062
                        ? "CPF ou RG já cadastrado."
                        : "Não foi possível cadastrar o cliente no banco de dados.");
                return View(cliente);
            }
        }

        [HttpGet]
        public IActionResult Editar(int id)
        {
            using var conexao = _banco.CriarConexao();
            conexao.Open();
            var cliente = BuscarCliente(conexao, id);
            return cliente == null ? NotFound() : View(cliente);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Editar(Cliente cliente)
        {
            if (!ModelState.IsValid)
                return View(cliente);

            using var conexao = _banco.CriarConexao();
            conexao.Open();

            const string sql = @"
                UPDATE cliente
                SET nome=@nome, cpf=@cpf, telefone=@telefone,
                    email=@email, RG=@rg, senha=@senha
                WHERE id_cliente=@id;";

            using var comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@nome", cliente.Nome);
            comando.Parameters.AddWithValue("@cpf", cliente.CPF);
            comando.Parameters.AddWithValue("@telefone", cliente.Tel);
            comando.Parameters.AddWithValue("@email", cliente.Email);
            comando.Parameters.AddWithValue("@rg", cliente.RG);
            comando.Parameters.AddWithValue("@senha", cliente.Senha);
            comando.Parameters.AddWithValue("@id", cliente.Id);
            comando.ExecuteNonQuery();

            TempData["Sucesso"] = "Cliente atualizado com sucesso.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Excluir(int id)
        {
            using var conexao = _banco.CriarConexao();
            conexao.Open();
            using var transacao = conexao.BeginTransaction();

            try
            {
                foreach (var tabela in new[] { "deposito", "pagamento", "emprestimo", "saldo" })
                {
                    using var comandoFilho = new MySqlCommand($"DELETE FROM {tabela} WHERE id_cliente=@id;", conexao, transacao);
                    comandoFilho.Parameters.AddWithValue("@id", id);
                    comandoFilho.ExecuteNonQuery();
                }

                using var comandoCliente = new MySqlCommand("DELETE FROM cliente WHERE id_cliente=@id;", conexao, transacao);
                comandoCliente.Parameters.AddWithValue("@id", id);
                comandoCliente.ExecuteNonQuery();

                transacao.Commit();
                TempData["Sucesso"] = "Cliente excluído com sucesso.";
            }
            catch
            {
                transacao.Rollback();
                TempData["Erro"] = "Não foi possível excluir o cliente.";
            }

            return RedirectToAction(nameof(Index));
        }

        private static Cliente? BuscarCliente(MySqlConnection conexao, int id)
        {
            const string sql = @"
                SELECT id_cliente, nome, cpf, telefone, email, RG, senha
                FROM cliente
                WHERE id_cliente=@id;";

            using var comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@id", id);
            using var leitor = comando.ExecuteReader();
            return leitor.Read() ? LerCliente(leitor) : null;
        }

        private static Cliente LerCliente(MySqlDataReader leitor)
        {
            return new Cliente
            {
                Id = Convert.ToInt32(leitor["id_cliente"]),
                Nome = Convert.ToString(leitor["nome"]) ?? string.Empty,
                CPF = Convert.ToString(leitor["cpf"]) ?? string.Empty,
                Tel = leitor.IsDBNull(leitor.GetOrdinal("telefone")) ? string.Empty : Convert.ToString(leitor["telefone"]) ?? string.Empty,
                Email = Convert.ToString(leitor["email"]) ?? string.Empty,
                RG = Convert.ToString(leitor["RG"]) ?? string.Empty,
                Senha = Convert.ToString(leitor["senha"]) ?? string.Empty
            };
        }

        private static Saldo BuscarSaldo(MySqlConnection conexao, int idCliente)
        {
            const string sql = "SELECT id_saldo, id_cliente, saldo_atual FROM saldo WHERE id_cliente=@id LIMIT 1;";
            using var comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@id", idCliente);
            using var leitor = comando.ExecuteReader();

            if (leitor.Read())
            {
                return new Saldo
                {
                    Id = Convert.ToInt32(leitor["id_saldo"]),
                    IdCliente = Convert.ToInt32(leitor["id_cliente"]),
                    SaldoAtual = Convert.ToDecimal(leitor["saldo_atual"])
                };
            }

            return new Saldo { IdCliente = idCliente, SaldoAtual = 0m };
        }

        private static List<Deposito> BuscarDepositos(MySqlConnection conexao, int idCliente)
        {
            var lista = new List<Deposito>();
            const string sql = "SELECT id_deposito, id_cliente, valor, data_deposito FROM deposito WHERE id_cliente=@id ORDER BY data_deposito DESC;";
            using var comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@id", idCliente);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Deposito
                {
                    Id = Convert.ToInt32(leitor["id_deposito"]),
                    IdCliente = Convert.ToInt32(leitor["id_cliente"]),
                    ValorDeposito = Convert.ToDecimal(leitor["valor"]),
                    DataDeposito = Convert.ToDateTime(leitor["data_deposito"])
                });
            }
            return lista;
        }

        private static List<Pagamento> BuscarPagamentos(MySqlConnection conexao, int idCliente)
        {
            var lista = new List<Pagamento>();
            const string sql = "SELECT id_pagamento, id_cliente, valor, beneficiario, data_pagamento FROM pagamento WHERE id_cliente=@id ORDER BY data_pagamento DESC;";
            using var comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@id", idCliente);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Pagamento
                {
                    Id = Convert.ToInt32(leitor["id_pagamento"]),
                    IdCliente = Convert.ToInt32(leitor["id_cliente"]),
                    ValorPago = Convert.ToDecimal(leitor["valor"]),
                    Beneficiario = Convert.ToString(leitor["beneficiario"]) ?? string.Empty,
                    DataRealizacao = Convert.ToDateTime(leitor["data_pagamento"])
                });
            }
            return lista;
        }

        private static List<Emprestimo> BuscarEmprestimos(MySqlConnection conexao, int idCliente)
        {
            var lista = new List<Emprestimo>();
            const string sql = @"
                SELECT id_emprestimo, id_cliente, valor, quantidade_parcelas, valor_parcela, data_emprestimo
                FROM emprestimo WHERE id_cliente=@id ORDER BY data_emprestimo DESC;";
            using var comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@id", idCliente);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Emprestimo
                {
                    Id = Convert.ToInt32(leitor["id_emprestimo"]),
                    IdCliente = Convert.ToInt32(leitor["id_cliente"]),
                    ValorEmprestimo = Convert.ToDecimal(leitor["valor"]),
                    QuantidadeParcelas = Convert.ToInt32(leitor["quantidade_parcelas"]),
                    ValorParcela = Convert.ToDecimal(leitor["valor_parcela"]),
                    DataEmprestimo = Convert.ToDateTime(leitor["data_emprestimo"])
                });
            }
            return lista;
        }
    }
}
