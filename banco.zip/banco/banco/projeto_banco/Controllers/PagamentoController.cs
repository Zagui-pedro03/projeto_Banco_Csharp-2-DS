using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using projeto_banco.Data;
using projeto_banco.Models;

namespace projeto_banco.Controllers
{
    public class PagamentoController : Controller
    {
        private readonly BancoContext _banco;

        public PagamentoController(BancoContext banco)
        {
            _banco = banco;
        }

        public IActionResult Index()
        {
            var lista = new List<Pagamento>();
            using var conexao = _banco.CriarConexao();
            conexao.Open();

            const string sql = @"
                SELECT p.id_pagamento, p.id_cliente, p.valor, p.beneficiario, p.data_pagamento,
                       c.nome, c.cpf
                FROM pagamento p
                INNER JOIN cliente c ON c.id_cliente=p.id_cliente
                ORDER BY p.data_pagamento DESC;";

            using var comando = new MySqlCommand(sql, conexao);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Pagamento
                {
                    Id = Convert.ToInt32(leitor["id_pagamento"]),
                    IdCliente = Convert.ToInt32(leitor["id_cliente"]),
                    ValorPago = Convert.ToDecimal(leitor["valor"]),
                    Beneficiario = Convert.ToString(leitor["beneficiario"]) ?? string.Empty,
                    DataRealizacao = Convert.ToDateTime(leitor["data_pagamento"]),
                    Cliente = new Cliente
                    {
                        Id = Convert.ToInt32(leitor["id_cliente"]),
                        Nome = Convert.ToString(leitor["nome"]) ?? string.Empty,
                        CPF = Convert.ToString(leitor["cpf"]) ?? string.Empty
                    }
                });
            }
            return View(lista);
        }

        [HttpGet]
        public IActionResult Cadastrar()
        {
            CarregarClientes();
            return View(new Pagamento());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cadastrar(Pagamento pagamento)
        {
            if (!ModelState.IsValid)
            {
                CarregarClientes();
                return View(pagamento);
            }

            using var conexao = _banco.CriarConexao();
            conexao.Open();
            using var transacao = conexao.BeginTransaction();

            try
            {
                decimal saldoAtual;
                using (var consultaSaldo = new MySqlCommand(
                    "SELECT saldo_atual FROM saldo WHERE id_cliente=@idCliente FOR UPDATE;",
                    conexao, transacao))
                {
                    consultaSaldo.Parameters.AddWithValue("@idCliente", pagamento.IdCliente);
                    var resultado = consultaSaldo.ExecuteScalar();
                    saldoAtual = resultado == null || resultado == DBNull.Value ? 0m : Convert.ToDecimal(resultado);
                }

                if (saldoAtual < pagamento.ValorPago)
                {
                    transacao.Rollback();
                    ModelState.AddModelError(nameof(Pagamento.ValorPago), "Saldo insuficiente para este pagamento.");
                    CarregarClientes();
                    return View(pagamento);
                }

                using var comando = new MySqlCommand(@"
                    INSERT INTO pagamento (id_cliente, valor, beneficiario)
                    VALUES (@idCliente, @valor, @beneficiario);", conexao, transacao);
                comando.Parameters.AddWithValue("@idCliente", pagamento.IdCliente);
                comando.Parameters.AddWithValue("@valor", pagamento.ValorPago);
                comando.Parameters.AddWithValue("@beneficiario", pagamento.Beneficiario);
                comando.ExecuteNonQuery();

                using var atualiza = new MySqlCommand(
                    "UPDATE saldo SET saldo_atual = saldo_atual - @valor WHERE id_cliente=@idCliente;",
                    conexao, transacao);
                atualiza.Parameters.AddWithValue("@valor", pagamento.ValorPago);
                atualiza.Parameters.AddWithValue("@idCliente", pagamento.IdCliente);
                atualiza.ExecuteNonQuery();

                transacao.Commit();
                TempData["Sucesso"] = "Pagamento realizado com sucesso.";
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                transacao.Rollback();
                ModelState.AddModelError(string.Empty, "Não foi possível realizar o pagamento.");
                CarregarClientes();
                return View(pagamento);
            }
        }

        private void CarregarClientes()
        {
            var clientes = new List<Cliente>();
            using var conexao = _banco.CriarConexao();
            conexao.Open();
            using var comando = new MySqlCommand("SELECT id_cliente, nome, cpf FROM cliente ORDER BY nome;", conexao);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                clientes.Add(new Cliente { Id = Convert.ToInt32(leitor["id_cliente"]), Nome = Convert.ToString(leitor["nome"]) ?? string.Empty, CPF = Convert.ToString(leitor["cpf"]) ?? string.Empty });
            }
            ViewBag.Clientes = clientes;
        }
    }
}
