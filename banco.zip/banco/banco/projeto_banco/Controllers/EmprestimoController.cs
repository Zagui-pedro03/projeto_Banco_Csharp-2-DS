using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using projeto_banco.Data;
using projeto_banco.Models;

namespace projeto_banco.Controllers
{
    public class EmprestimoController : Controller
    {
        private readonly BancoContext _banco;

        public EmprestimoController(BancoContext banco)
        {
            _banco = banco;
        }

        public IActionResult Index()
        {
            var lista = new List<Emprestimo>();
            using var conexao = _banco.CriarConexao();
            conexao.Open();

            const string sql = @"
                SELECT e.id_emprestimo, e.id_cliente, e.valor, e.quantidade_parcelas,
                       e.valor_parcela, e.data_emprestimo, c.nome, c.cpf
                FROM emprestimo e
                INNER JOIN cliente c ON c.id_cliente=e.id_cliente
                ORDER BY e.data_emprestimo DESC;";

            using var comando = new MySqlCommand(sql, conexao);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Emprestimo
                {
                    Id = Convert.ToInt32(leitor["id_emprestimo"]),
                    IdCliente = Convert.ToInt32(leitor["id_cliente"]),
                    ValorEmprestimo = Convert.ToDecimal(leitor["valor"]),
                    QuantidadeParcelas = Convert.ToInt32(leitor["quantidade_parcelas"]),
                    ValorParcela = Convert.ToDecimal(leitor["valor_parcela"]),
                    DataEmprestimo = Convert.ToDateTime(leitor["data_emprestimo"]),
                    Cliente = new Cliente
                    {
                        Id = Convert.ToInt32(leitor["id_cliente"]),
                        Nome = Convert.ToString(leitor["nome"]) ?? string.Empty,
                        CPF = Convert.ToString(leitor["cpf"]) ?? string.Empty
                    }
                });
            }
            return View(lista);
        }

        [HttpGet]
        public IActionResult Cadastrar()
        {
            CarregarClientes();
            return View(new Emprestimo { QuantidadeParcelas = 12 });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cadastrar(Emprestimo emprestimo)
        {
            if (!ModelState.IsValid)
            {
                CarregarClientes();
                return View(emprestimo);
            }

            emprestimo.ValorParcela = Math.Round(emprestimo.ValorEmprestimo / emprestimo.QuantidadeParcelas, 2);

            using var conexao = _banco.CriarConexao();
            conexao.Open();
            using var transacao = conexao.BeginTransaction();

            try
            {
                using var comando = new MySqlCommand(@"
                    INSERT INTO emprestimo (id_cliente, valor, quantidade_parcelas, valor_parcela)
                    VALUES (@idCliente, @valor, @parcelas, @valorParcela);", conexao, transacao);
                comando.Parameters.AddWithValue("@idCliente", emprestimo.IdCliente);
                comando.Parameters.AddWithValue("@valor", emprestimo.ValorEmprestimo);
                comando.Parameters.AddWithValue("@parcelas", emprestimo.QuantidadeParcelas);
                comando.Parameters.AddWithValue("@valorParcela", emprestimo.ValorParcela);
                comando.ExecuteNonQuery();

                using var atualiza = new MySqlCommand(
                    "UPDATE saldo SET saldo_atual = saldo_atual + @valor WHERE id_cliente=@idCliente;",
                    conexao, transacao);
                atualiza.Parameters.AddWithValue("@valor", emprestimo.ValorEmprestimo);
                atualiza.Parameters.AddWithValue("@idCliente", emprestimo.IdCliente);
                var linhas = atualiza.ExecuteNonQuery();

                if (linhas == 0)
                {
                    using var criaSaldo = new MySqlCommand(
                        "INSERT INTO saldo (id_cliente, saldo_atual) VALUES (@idCliente, @valor);",
                        conexao, transacao);
                    criaSaldo.Parameters.AddWithValue("@idCliente", emprestimo.IdCliente);
                    criaSaldo.Parameters.AddWithValue("@valor", emprestimo.ValorEmprestimo);
                    criaSaldo.ExecuteNonQuery();
                }

                transacao.Commit();
                TempData["Sucesso"] = "Empréstimo registrado e creditado no saldo.";
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                transacao.Rollback();
                ModelState.AddModelError(string.Empty, "Não foi possível registrar o empréstimo.");
                CarregarClientes();
                return View(emprestimo);
            }
        }

        private void CarregarClientes()
        {
            var clientes = new List<Cliente>();
            using var conexao = _banco.CriarConexao();
            conexao.Open();
            using var comando = new MySqlCommand("SELECT id_cliente, nome, cpf FROM cliente ORDER BY nome;", conexao);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                clientes.Add(new Cliente { Id = Convert.ToInt32(leitor["id_cliente"]), Nome = Convert.ToString(leitor["nome"]) ?? string.Empty, CPF = Convert.ToString(leitor["cpf"]) ?? string.Empty });
            }
            ViewBag.Clientes = clientes;
        }
    }
}
