using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using projeto_banco.Data;
using projeto_banco.Models;

namespace projeto_banco.Controllers
{
    public class DepositoController : Controller
    {
        private readonly BancoContext _banco;

        public DepositoController(BancoContext banco)
        {
            _banco = banco;
        }

        public IActionResult Index()
        {
            var lista = new List<Deposito>();
            using var conexao = _banco.CriarConexao();
            conexao.Open();

            const string sql = @"
                SELECT d.id_deposito, d.id_cliente, d.valor, d.data_deposito,
                       c.nome, c.cpf
                FROM deposito d
                INNER JOIN cliente c ON c.id_cliente=d.id_cliente
                ORDER BY d.data_deposito DESC;";

            using var comando = new MySqlCommand(sql, conexao);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Deposito
                {
                    Id = Convert.ToInt32(leitor["id_deposito"]),
                    IdCliente = Convert.ToInt32(leitor["id_cliente"]),
                    ValorDeposito = Convert.ToDecimal(leitor["valor"]),
                    DataDeposito = Convert.ToDateTime(leitor["data_deposito"]),
                    Cliente = new Cliente
                    {
                        Id = Convert.ToInt32(leitor["id_cliente"]),
                        Nome = Convert.ToString(leitor["nome"]) ?? string.Empty,
                        CPF = Convert.ToString(leitor["cpf"]) ?? string.Empty
                    }
                });
            }

            return View(lista);
        }

        [HttpGet]
        public IActionResult Cadastrar()
        {
            CarregarClientes();
            return View(new Deposito());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Cadastrar(Deposito deposito)
        {
            if (!ModelState.IsValid)
            {
                CarregarClientes();
                return View(deposito);
            }

            using var conexao = _banco.CriarConexao();
            conexao.Open();
            using var transacao = conexao.BeginTransaction();

            try
            {
                using var comando = new MySqlCommand(
                    "INSERT INTO deposito (id_cliente, valor) VALUES (@idCliente, @valor);",
                    conexao, transacao);
                comando.Parameters.AddWithValue("@idCliente", deposito.IdCliente);
                comando.Parameters.AddWithValue("@valor", deposito.ValorDeposito);
                comando.ExecuteNonQuery();

                using var atualiza = new MySqlCommand(
                    "UPDATE saldo SET saldo_atual = saldo_atual + @valor WHERE id_cliente=@idCliente;",
                    conexao, transacao);
                atualiza.Parameters.AddWithValue("@valor", deposito.ValorDeposito);
                atualiza.Parameters.AddWithValue("@idCliente", deposito.IdCliente);
                var linhas = atualiza.ExecuteNonQuery();

                if (linhas == 0)
                {
                    using var criaSaldo = new MySqlCommand(
                        "INSERT INTO saldo (id_cliente, saldo_atual) VALUES (@idCliente, @valor);",
                        conexao, transacao);
                    criaSaldo.Parameters.AddWithValue("@idCliente", deposito.IdCliente);
                    criaSaldo.Parameters.AddWithValue("@valor", deposito.ValorDeposito);
                    criaSaldo.ExecuteNonQuery();
                }

                transacao.Commit();
                TempData["Sucesso"] = "Depósito realizado com sucesso.";
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                transacao.Rollback();
                ModelState.AddModelError(string.Empty, "Não foi possível realizar o depósito.");
                CarregarClientes();
                return View(deposito);
            }
        }

        private void CarregarClientes()
        {
            var clientes = new List<Cliente>();
            using var conexao = _banco.CriarConexao();
            conexao.Open();
            using var comando = new MySqlCommand("SELECT id_cliente, nome, cpf FROM cliente ORDER BY nome;", conexao);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                clientes.Add(new Cliente
                {
                    Id = Convert.ToInt32(leitor["id_cliente"]),
                    Nome = Convert.ToString(leitor["nome"]) ?? string.Empty,
                    CPF = Convert.ToString(leitor["cpf"]) ?? string.Empty
                });
            }
            ViewBag.Clientes = clientes;
        }
    }
}
