using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using projeto_banco.Data;
using projeto_banco.Models;

namespace projeto_banco.Controllers
{
    public class SaldoController : Controller
    {
        private readonly BancoContext _banco;

        public SaldoController(BancoContext banco)
        {
            _banco = banco;
        }

        public IActionResult Index()
        {
            var lista = new List<Saldo>();
            using var conexao = _banco.CriarConexao();
            conexao.Open();

            const string sql = @"
                SELECT s.id_saldo, s.id_cliente, s.saldo_atual, c.nome, c.cpf
                FROM saldo s
                INNER JOIN cliente c ON c.id_cliente=s.id_cliente
                ORDER BY c.nome;";

            using var comando = new MySqlCommand(sql, conexao);
            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Saldo
                {
                    Id = Convert.ToInt32(leitor["id_saldo"]),
                    IdCliente = Convert.ToInt32(leitor["id_cliente"]),
                    SaldoAtual = Convert.ToDecimal(leitor["saldo_atual"]),
                    Cliente = new Cliente
                    {
                        Id = Convert.ToInt32(leitor["id_cliente"]),
                        Nome = Convert.ToString(leitor["nome"]) ?? string.Empty,
                        CPF = Convert.ToString(leitor["cpf"]) ?? string.Empty
                    }
                });
            }

            return View(lista);
        }
    }
}
