using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using projeto_banco.Models;

namespace projeto_banco.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => View();

    public IActionResult Privacy() => View();

    public IActionResult Cadastro() => RedirectToAction("Cadastrar", "Cliente");

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
